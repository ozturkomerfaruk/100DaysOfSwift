import Cocoa

var greeting = "Hello, playground"

let str = "Good Bye"
var age = 38
var population = 8_000_000

var str1 = """
This goes
over multiple
lines
"""

var str2 = """
This goes \
over multiple \
lines
"""

print(str1)

print(str2)

var pi = 3.141

var awesome = true

var score = 85
print("Your score was \(score) ")

let kConstant = 2.5

print(kConstant)

let album: String = "Reputation"
let year: Int = 1998
let height: Double = 12.14
let taylorRocks: Bool = true

print("\(album) \(year) + \(height) + \(taylorRocks)")
